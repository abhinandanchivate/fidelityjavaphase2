
public class FactoryTest {

	public static void main(String[] args) {
		
		Computer computer = ComputerFactory.getComputer("pc", "16GB", "1TB", "2.4GHZ");
		
		System.out.println(computer);
		
		System.out.println(computer instanceof PC);
	}
}
