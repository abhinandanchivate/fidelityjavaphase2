package com.fidelity.employeemanagement.repository;

import com.fidelity.employeemanagement.dto.Login;

public interface LoginRepository {

	public Login findById(String userName);
}
