package com.fidelity.employeemanagement.service;

import com.fidelity.employeemanagement.dto.Login;
import com.fidelity.employeemanagement.repository.LoginRepository;
import com.fidelity.employeemanagement.repository.LoginRepositoryImpl;

public class LoginServiceImpl implements LoginService {

	LoginRepository loginRepo = new LoginRepositoryImpl();

	@Override
	public boolean authenticateUser(Login login) {
		// TODO Auto-generated method stub

		Login resultObj = loginRepo.findById(login.getUserName());

		return login.equals(resultObj);
	}

}
