package com.fidelity.employeemanagement.service;

import com.fidelity.employeemanagement.dto.Login;

public interface LoginService {

	public boolean authenticateUser(Login login);
}
