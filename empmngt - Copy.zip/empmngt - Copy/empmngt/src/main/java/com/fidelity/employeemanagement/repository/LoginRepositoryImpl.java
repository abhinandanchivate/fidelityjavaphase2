package com.fidelity.employeemanagement.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.fidelity.employeemanagement.dto.Login;
import com.fidelity.employeemanagement.utils.DBUtils;

public class LoginRepositoryImpl implements LoginRepository {

	@Override
	public Login findById(String userName) {
		// TODO Auto-generated method stub
		
		Connection connection = DBUtils.getConnection();
		try {
			PreparedStatement statement = connection.prepareStatement("select * from login where userName=?");
			statement.setString(1, userName);
			
			ResultSet resultSet = statement.executeQuery();
			if(resultSet.next()) {
				Login login = new Login(resultSet.getString("userName"),resultSet.getString("password"));
				return login;
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			DBUtils.closeConnection(connection);
		}
		
		return null;
	}

	
}
