package com.fidelity.employeemanagement.utils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

public class DBUtils {
	public DBUtils() {
		// TODO Auto-generated constructor stub
	System.out.println("constructor is called");
	}
	
	@PostConstruct
	public void init() {
		System.out.println("init is called");
	}
	@PreDestroy
	public void destroy() {
		System.out.println("destroy is called");
	}
	
	public  Connection	getConnection() {
Properties properties = DBUtils.readProperties();
		
		String driverName=(String)properties.get("driverName");
		String userName=(String)properties.get("userName");
		String password=(String)properties.get("password");
		String jdbcURL=(String)properties.get("jdbcURL");
		Connection connection = null;
		
		try {
			Class.forName((String) properties.get("driverName"));
		connection = DriverManager.getConnection(jdbcURL,userName,password);	
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return connection;
	}
	
	public  void closeConnection(Connection connection) {
		try {
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	public static Properties	readProperties() {
		InputStream fileInputStream = null;
		Properties properties = null;
		
		try {
			System.out.println("try begining");
			fileInputStream =DBUtils.class.getResourceAsStream("application.properties");
			System.out.println(fileInputStream!=null);
			properties = new Properties();
			properties.load(fileInputStream);
			System.out.println("inside the try");
			//return properties;
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			try {
				fileInputStream.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return properties;
		
		
	}
}
