package com.fidelity.employeemanagement.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import com.fidelity.employeemanagement.utils.DBUtils;

@Configuration
@ComponentScan(basePackages = "com.fidelity.employeemanagement")
public class PostgreSQLCOnfig {

	// we need to create the DBUtils bean
	
	// we need to scan @ service @ repo
	
	// we need to use service obj in main to perform the activities
	
	@Bean(name = "dbUtils")
	public DBUtils	getDBUtilsBean() {
		return new DBUtils();
	}

}
