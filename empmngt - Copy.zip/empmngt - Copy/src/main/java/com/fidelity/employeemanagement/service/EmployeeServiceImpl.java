package com.fidelity.employeemanagement.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fidelity.employeemanagement.dto.Employee;
import com.fidelity.employeemanagement.exception.DataNotFoundException;
import com.fidelity.employeemanagement.repository.EmployeeRepository;
import com.fidelity.employeemanagement.repository.EmployeeRepositoryImpl;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	EmployeeRepository employeeRepository ;
	public String addEmployee(Employee e) {
		// TODO Auto-generated method stub
		return employeeRepository.save(e);
	}

	public void removeEmployee(String id) {
		// TODO Auto-generated method stub
		 employeeRepository.delete(id);
	}

	public String updateEmployee(String id, Employee e) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Employee> getEmployees() {
		// TODO Auto-generated method stub
		employeeRepository.findAll().forEach(e->{
			System.out.println(e);
		});
		return employeeRepository.findAll();
	}

	public List<Employee> getEmployeesByName(String firstName) {
		// TODO Auto-generated method stub
		return null;
	}

	public void removeAllEmployees() {
		// TODO Auto-generated method stub

	}

	public Optional<Employee> getEmployeeById(String string) throws DataNotFoundException {
		// TODO Auto-generated method stub
		return employeeRepository.findById(string);
	}

	@Override
	public long count() {
		// TODO Auto-generated method stub
		return employeeRepository.count();
	}

}
