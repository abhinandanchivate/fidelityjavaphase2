package com.fidelity.employeemanagement.main;

import java.sql.Connection;
import java.util.List;
import java.util.Optional;
import java.util.Properties;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.fidelity.employeemanagement.config.PostgreSQLCOnfig;
import com.fidelity.employeemanagement.dto.Employee;
import com.fidelity.employeemanagement.exception.DataNotFoundException;
import com.fidelity.employeemanagement.exception.InvalidSalaryException;
import com.fidelity.employeemanagement.service.EmployeeService;
import com.fidelity.employeemanagement.service.EmployeeServiceImpl;
import com.fidelity.employeemanagement.utils.DBUtils;

public class Main {

	public static void main(String[] args) {
		Employee employee = null;
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(PostgreSQLCOnfig.class);
		
		DBUtils dbUtils = context.getBean(DBUtils.class);
		context.close();
//		EmployeeService employeeService = context.getBean(EmployeeService.class);
//		System.out.println(employeeService!=null);
//		System.out.println(employeeService.count());
//		List<Employee> list = employeeService.getEmployees();
//		
//		if(list!=null&& ! list.isEmpty()) {
//			list.forEach(e->{
//				System.out.println("data is "+e);
//			});
//		}
//		else {
//			System.out.println(list);
//		}
		
//	Optional<Employee> emOptional = null;
//	try {
//		emOptional = employeeService.getEmployeeById("AB001");
//	} catch (DataNotFoundException e) {
//		// TODO Auto-generated catch block
//		e.printStackTrace();
//	}
//	
//	if(emOptional.isPresent()) {
//		Employee employee2 = emOptional.get();
//		System.out.println(employee2);
//	}
//	else {
//		System.out.println("else executed"+emOptional.isPresent());
//	}
//		try {
//		 employee = new Employee("AB003", "abhi", "trainer", 123.0f);
//		 String result = employeeService.addEmployee(employee);
//		 if("success".equals(result)) {
//			 System.out.println("record added successfully");
//		 }
//		 else {
//			 System.out.println("problem");
//		 }
//		} catch (InvalidSalaryException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		
	}

}
