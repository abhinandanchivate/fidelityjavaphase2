package com.fidelity.springex;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;


public class HelloWorld {
public HelloWorld() {
	// TODO Auto-generated constructor stub
System.out.println("constrcutor called");
}
	
	public void sayHello() {
		
		System.out.println("hello from shree");
	}
}
