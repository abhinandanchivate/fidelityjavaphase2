package com.fidelity.springex.config;

import javax.sql.DataSource;

import org.apache.commons.dbcp2.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.context.annotation.Scope;
import org.springframework.core.env.Environment;

import com.fidelity.springex.BeanOne;
import com.fidelity.springex.BeanThree;
import com.fidelity.springex.BeanTwo;
import com.fidelity.springex.HelloWorld;

@Configuration
//@ImportResource(locations = {"classpath:beans.xml"})
@Import(value = {PostgreSQLCOnfig.class})
@ComponentScan(basePackages = "com.fidelity.springex")
@PropertySources(value = {@PropertySource("classpath:db.properties"),
		@PropertySource("classpath:${db1.name}.properties"),
		@PropertySource("classpath:${db2.name}.properties")})
public class DBConfig {

	@Bean("beanOne")
	@DependsOn(value= {"beanTwo","beanThree"})
	public BeanOne getBeanOne() {
		return new BeanOne();
	}
	
	@Bean("beanTwo")
	public BeanTwo getBeanTwo() {
		return new BeanTwo();
	}
	
	@Bean("beanThree")
	public BeanThree getBeanThree() {
		return new BeanThree();
	}
	
	@Bean("helloWorld")
	@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
	public HelloWorld getHelloWorld() {
		return new HelloWorld();
	}
	@Autowired  
	private Environment env;
	
	@Bean("mysql")
//
	// it will take scope = singleton
	public DataSource getMySQLDataSource() {
		
		BasicDataSource dataSource = new BasicDataSource();
		System.out.println("hello from mehotd");
		dataSource.setDriverClassName(env.getProperty("db.driver"));
		dataSource.setUrl(env.getProperty("db.url"));
		dataSource.setUsername(env.getProperty("db.username"));
		dataSource.setPassword(env.getProperty("db.password"));
		return dataSource;
	}
	
	@Bean("postgresql")
public DataSource getpostSQLDataSource() {
		
		BasicDataSource dataSource = new BasicDataSource();
		System.out.println("hello from mehotd");
		dataSource.setDriverClassName(env.getProperty("jdbc.driver"));
		dataSource.setUrl(env.getProperty("jdbc.url"));
		dataSource.setUsername(env.getProperty("jdbc.username"));
		dataSource.setPassword(env.getProperty("jdbc.password"));
		return dataSource;
	}
	
	
	
	
}
