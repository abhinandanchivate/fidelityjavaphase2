package com.fidelity.springex;

import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;


public class BeanTwo {
	public BeanTwo() {
		// TODO Auto-generated constructor stub
	System.out.println("Bean Two COnstructor");
	}
	public void dosomething() {
		System.out.println("inside the dosomething of bean two");
	}

}
