package com.fidelity.springex;

public class BeanThree {
	
	public BeanThree() {
		// TODO Auto-generated constructor stub
	System.out.println("Bean Three constructor executed");
	}
	
	public void doSomething() {
		System.out.println("inside dosomething bean three");
	}

}
