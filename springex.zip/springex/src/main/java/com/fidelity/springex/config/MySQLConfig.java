package com.fidelity.springex.config;

public class MySQLConfig {

}
