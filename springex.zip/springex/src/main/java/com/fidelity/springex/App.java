package com.fidelity.springex;

import javax.sql.DataSource;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

import com.fidelity.springex.config.DBConfig;
import com.fidelity.springex.config.PostgreSQLCOnfig;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
     // ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
      //HelloWorld helloWorld = context.getBean("helloWorld",HelloWorld.class);
      
      //helloWorld.sayHello();
  //    XmlBeanFactory factory = new XmlBeanFactory(new ClassPathResource("beans.xml"));
      
//      HelloWorld helloWorld  = factory.getBean("helloWorld", HelloWorld.class);
//      helloWorld.sayHello();
//      HelloWorld helloWorld2 = factory.getBean("helloWorld", HelloWorld.class);
//      System.out.println(helloWorld.equals(helloWorld2));
//      System.out.println(helloWorld.hashCode());
//      System.out.println(helloWorld2.hashCode());
      
    	AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(DBConfig.class);
    	
    	BeanOne beanOne = context.getBean(BeanOne.class);
    	//BeanTwo beanTwo = context.getBean(BeanTwo.class);
    	//BeanThree beanThree = context.getBean(BeanThree.class);
    	
//    	HelloWorld helloWorld  = context.getBean("helloWorld",HelloWorld.class);
//    	HelloWorld helloWorld2  = context.getBean("helloWorld",HelloWorld.class);
//    	
//    	System.out.println(helloWorld.equals(helloWorld2));
//    	System.out.println(helloWorld.hashCode());
//    	System.out.println(helloWorld2.hashCode());
    	
//      DataSource dataSource = context.getBean("mysql", DataSource.class);
//      System.out.println(dataSource.hashCode());
//      DataSource dataSource2 = context.getBean("postgresqlBean", DataSource.class);
//      System.out.println(dataSource2.getClass());
//      System.out.println(dataSource.equals(dataSource2));
//      HelloWorld helloWorld = context.getBean("helloWorld",HelloWorld.class);
//      helloWorld.sayHello();
//      
////      BeanTwo beanTwo = context.getBean("beanTwo",BeanTwo.class);
////      beanTwo.dosomething();
//      BeanOne beanOne = context.getBean(BeanOne.class);
//      beanOne.dosomething();
      
//      RepositorySample repositorySample = context.getBean("repository",RepositorySample.class);
//      repositorySample.repo();
      context.close();
    }
}
