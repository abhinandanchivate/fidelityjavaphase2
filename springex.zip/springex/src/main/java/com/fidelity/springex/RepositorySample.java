package com.fidelity.springex;

import org.springframework.stereotype.Repository;

@Repository
public class RepositorySample {

	public void repo() {
		System.out.println("inside the repository");
	}
}
