package com.fidelity.springex;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;


public class BeanOne {
	
//	private BeanTwo beanTwo;
//
//	public BeanTwo getBeanTwo() {
//		return beanTwo;
//	}
//
//	public void setBeanTwo(BeanTwo beanTwo) {
//		this.beanTwo = beanTwo;
//	}
	
	@Autowired
	private BeanTwo beanTwo;
	
	@Autowired
	private BeanThree beanThree;
	
	public void dosomething() {
		System.out.println("inside the dosomething method of Bean one");
		//beanTwo.dosomething();
		//repository.repo();
	}
	public BeanOne() {
		// TODO Auto-generated constructor stub
	System.out.println("inside the Bean one constructor");
	}
	

}
