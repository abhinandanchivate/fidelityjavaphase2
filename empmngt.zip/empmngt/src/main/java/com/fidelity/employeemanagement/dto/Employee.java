package com.fidelity.employeemanagement.dto;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.Arrays;

import com.fidelity.employeemanagement.exception.InvalidSalaryException;

public  class Employee 
//implements Comparable<Employee>
{
//	
//	HashMap<Integer,HashMap<String,List<Employee>>> 
//	
//	/*
//	 * K --->V HashMap<key,Value>  
//	 * 1 ---> <trainer,List<Employee>> 
//	 * 
//	 */
	 String empId;
	
	private String address;
	private String designation;
	private float empSalary;
	private String empFirstName;
	private String empLastName;
	private static Employee employee;
	 // can i declare a single method to set all the values ? 
	
	public  float calculateSalary() {
		return empSalary + (empSalary*10/100) + (empSalary*15/100) + (empSalary*5/100);
		
	}

	public String getEmpId() {
		return new String(empId);
	}
	public Employee() {
		// explicit default constructor
		// TODO Auto-generated constructor stub
		System.out.println("default constructro executed ");
	}
	public Employee(String empId, String empFirstName, String designation, float empSalary) throws InvalidSalaryException {
		super();
		//System.out.println("constructor called");
		this.empId = empId;
		this.empFirstName = empFirstName;
		this.designation = designation;
		this.setEmpSalary(empSalary);
	}
	public Employee(String empId, String empFirstName, String empLastName, String address, String designation,
			float empSalary) throws InvalidSalaryException {
		// constructor chaining
		// this method for constructor chaining
		// this method must be a first call of constructor block 
		this(empId,empFirstName,designation,empSalary);
		this.empLastName = empLastName;
		// work with empId 
		
		this.address = address;
		// diff between this keyword and this method
		
		// this keyword is used to access object contents & to call methods
		// this() is used to call one construcvtor into another.
		
	}
	
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getEmpFirstName() {
		return empFirstName;
	}
	public void setEmpFirstName(String empFirstName) {
		this.empFirstName = empFirstName;
	}
	public String getEmpLastName() {
		return empLastName;
	}
	public void setEmpLastName(String empLastName) {
		this.empLastName = empLastName;
	}
	public String getAddress() {
		return address;
	}
	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((address == null) ? 0 : address.hashCode());
		result = prime * result + ((designation == null) ? 0 : designation.hashCode());
		result = prime * result + ((empId == null) ? 0 : empId.hashCode());
		result = prime * result + Float.floatToIntBits(empSalary);
		return result;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", address=" + address + ", designation=" + designation + ", empSalary="
				+ empSalary + ", empFirstName=" + empFirstName + ", empLastName=" + empLastName + "]";
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (address == null) {
			if (other.address != null)
				return false;
		} else if (!address.equals(other.address))
			return false;
		if (designation == null) {
			if (other.designation != null)
				return false;
		} else if (!designation.equals(other.designation))
			return false;
		if (empId == null) {
			if (other.empId != null)
				return false;
		} else if (!empId.equals(other.empId))
			return false;
		if (Float.floatToIntBits(empSalary) != Float.floatToIntBits(other.empSalary))
			return false;
		return true;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public float getEmpSalary() {
		return empSalary;
	}
	public void setEmpSalary(float empSalary) throws InvalidSalaryException {
		if(empSalary<0) {
			// raise the exception
			throw new InvalidSalaryException("salary should not be negative");
		}
		else 
		this.empSalary = empSalary;
	}

//	@Override
//	public int compareTo(Employee o) {
//		// TODO Auto-generated method stub
//		return this.empId.compareTo(o.empId);
//	}

}
