package com.fidelity.employeemanagement.repository;

import java.util.List;
import java.util.Optional;

import com.fidelity.employeemanagement.dto.Employee;

public interface EmployeeRepository {
	// to insert the record
	public String save(Employee employee);
	// search on the basis of id to get all details for an empl
	public Optional<Employee> findById(String id);
	// to update the employee details on the basis of id
	public String update(String id, Employee employee);
	// delete the record on the basis of id
	public void delete(String id);
	// delete all records 
	public void deleteAll();
	// retrieve all the records
	public List<Employee> findAll();
	// check whether the id exists 
	public boolean existsById(String id);
	// to take count or total number of records
	public long count();

}
