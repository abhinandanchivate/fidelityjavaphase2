package com.fidelity.employeemanagement.cotroller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fidelity.employeemanagement.dto.Login;
import com.fidelity.employeemanagement.service.LoginService;
import com.fidelity.employeemanagement.service.LoginServiceImpl;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ServletContext context ;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
@Override
public void init(ServletConfig config) throws ServletException {
	// TODO Auto-generated method stub
	context = config.getServletContext();
}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		LoginService servic= new LoginServiceImpl();
		String userName = request.getParameter("userName");
		String password =request.getParameter("password");
		
		System.out.println("do post method called");
		System.out.println(userName);
		System.out.println(password);
		Login login = new Login(userName, password);
		if(servic.authenticateUser(login)) {
			// redirect to userDashboard.html
			//response.sendRedirect("http://www.google.com");
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("userDashboard.jsp");
			context.setAttribute("account", "account");
			context.setAttribute("about", "aboutUs");
			context.setAttribute("contact", "contactUs");
			request.setAttribute("userName", "shivaraj");
			requestDispatcher.forward(request, response);
		}
		else {
			// redirect to login again
			response.sendRedirect("login.html");
		}
	}

}
