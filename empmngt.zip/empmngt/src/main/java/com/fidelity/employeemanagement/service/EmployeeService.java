package com.fidelity.employeemanagement.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.fidelity.employeemanagement.dto.Employee;
import com.fidelity.employeemanagement.exception.DataNotFoundException;

public interface EmployeeService {
	
	public String addEmployee(Employee e) ;

	public void removeEmployee(String id);
	public String updateEmployee(String id, Employee e) ;
	public List<Employee> getEmployees() ;
	public List<Employee> getEmployeesByName(String firstName) ;
	public void removeAllEmployees() ;
	public long count();
	public Optional<Employee> getEmployeeById(String string) throws DataNotFoundException;

}
