package com.fidelity.employeemanagement.exception;

public class InvalidSalaryException  extends Exception {

	public InvalidSalaryException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "InvalidSalaryException [toString()=" + super.getMessage() + "]";
	}
	
	

}
