package com.fidelity.employeemanagement.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

import com.fidelity.employeemanagement.dto.Employee;
import com.fidelity.employeemanagement.exception.InvalidSalaryException;
import com.fidelity.employeemanagement.utils.DBUtils;

public class EmployeeRepositoryImpl implements EmployeeRepository {

	private static EmployeeRepository employeeRepository;
	
	private EmployeeRepositoryImpl() {
		// TODO Auto-generated constructor stub
		
	}
	public static EmployeeRepository getInstance() {
		if(employeeRepository== null) {
			employeeRepository = new EmployeeRepositoryImpl();
			return employeeRepository;
		}
		return employeeRepository;
	}
	
	public String save(Employee employee) {
		// TODO Auto-generated method stub
		Connection connection = DBUtils.getConnection();
		
		PreparedStatement preparedStatement  = null;
		String insertStatement= "insert into employee (empId,empFirstName,empLastName,empDesgnation,empSalary,address) values(?,?,?,?,?,?)";
		
		// we have to hit this stmt to db 
		try {
			connection.setAutoCommit(false);
			preparedStatement = connection.prepareStatement(insertStatement);
			preparedStatement.setString(1, employee.getEmpId());
			preparedStatement.setString(2, employee.getEmpFirstName());
			preparedStatement.setString(3, employee.getEmpLastName());
			preparedStatement.setString(4, employee.getDesignation());
			preparedStatement.setDouble(5, employee.getEmpSalary());
			preparedStatement.setString(6, employee.getAddress());
			
		int result =	preparedStatement.executeUpdate();
		connection.commit();
		if(result>0) {
			return "success";
		}
		else {
			return "fail";
		}
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				connection.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			return "fail";
		}
		finally {
			DBUtils.closeConnection(connection);
		}
		// then we have to return success/fail accordingly
		
		
	}

	public Optional<Employee> findById(String id) {
		// TODO Auto-generated method stub
		String query = "select * from employee where empId=?";
		Connection connection = null;
		ResultSet resultSet = null;
		PreparedStatement preparedStatement = null;
		
		
		try {
			connection= DBUtils.getConnection();
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, id);
			
			resultSet  = preparedStatement.executeQuery();
			Employee employee = null;
			if(resultSet.next()) {
				 employee = new Employee();
				 employee.setEmpId(resultSet.getString("empId"));
				 employee.setEmpFirstName(resultSet.getString("empFirstName"));
				 employee.setEmpLastName(resultSet.getString("empLastName"));
				 try {
					employee.setEmpSalary(resultSet.getFloat("empSalary"));
				} catch (InvalidSalaryException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				 employee.setDesignation(resultSet.getString("empDesgnation"));
				 
				 
				 
			}
			
			// return object
			
			Optional<Employee> optional = Optional.ofNullable(employee);
			
			return optional;
			
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return null;
	}

	public String update(String id, Employee employee) {
		// TODO Auto-generated method stub
		return null;
	}

	public void delete(String id) {
		// TODO Auto-generated method stub
		
		String deleteStatement= "delete from employee where empId=?";
		Connection connection = DBUtils.getConnection();
		
		PreparedStatement preparedStatement = null;
		
		try {
			connection.setAutoCommit(false);
			preparedStatement = connection.prepareStatement(deleteStatement);
			preparedStatement.setString(1, id);
			preparedStatement.executeUpdate();
			connection.commit();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				connection.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		finally {
			DBUtils.closeConnection(connection);
		}
		

	}

	public void deleteAll() {
		String deleteStatement= "delete from employee";
		Connection connection = DBUtils.getConnection();
		
		PreparedStatement preparedStatement = null;
		
		try {
			connection.setAutoCommit(false);
			preparedStatement = connection.prepareStatement(deleteStatement);
			//preparedStatement.setString(1, id);
			preparedStatement.executeUpdate();
			connection.commit();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				connection.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		finally {
			DBUtils.closeConnection(connection);
		}
	}

	public List<Employee> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean existsById(String id) {
		// TODO Auto-generated method stub
		return false;
	}

	public long count() {
		// TODO Auto-generated method stub
		return 0;
	}

}
