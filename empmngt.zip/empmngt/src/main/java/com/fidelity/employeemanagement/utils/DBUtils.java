package com.fidelity.employeemanagement.utils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBUtils {
	
	public static Connection	getConnection() {
Properties properties = DBUtils.readProperties();
		
		String driverName=(String)properties.get("driverName");
		String userName=(String)properties.get("userName");
		String password=(String)properties.get("password");
		String jdbcURL=(String)properties.get("jdbcURL");
		Connection connection = null;
		
		try {
			//Class.forName((String) properties.get("driverName"));
		connection = DriverManager.getConnection(jdbcURL,userName,password);	
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return connection;
	}
	
	public static void closeConnection(Connection connection) {
		try {
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	public static Properties	readProperties() {
		FileInputStream fileInputStream = null;
		Properties properties = null;
		
		try {
			fileInputStream = new FileInputStream("application.properties");
			properties = new Properties();
			properties.load(fileInputStream);
			//return properties;
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			try {
				fileInputStream.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return properties;
		
		
	}
}
