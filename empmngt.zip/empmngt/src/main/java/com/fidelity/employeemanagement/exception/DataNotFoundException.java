package com.fidelity.employeemanagement.exception;

public class DataNotFoundException extends Exception {

	public DataNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "DataNotFoundException ["+super.getMessage()+"]";
	}

}
